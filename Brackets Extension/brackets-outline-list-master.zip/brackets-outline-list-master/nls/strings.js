define(function (require, exports, module) {
    module.exports = {
        root: true,
        de: true,
        fr: true,
        ja: true
    };
});
