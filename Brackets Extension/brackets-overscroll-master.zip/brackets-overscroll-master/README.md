# Overscroll for Brackets
A very simple extension for [Brackets](https://github.com/adobe/brackets/) to allow you to scroll below the document.

